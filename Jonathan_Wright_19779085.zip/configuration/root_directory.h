const char * logl_root = "/home/cg/Desktop/OpenGL 3.3 (COMP2004)";
