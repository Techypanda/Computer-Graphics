Relevant Source Files: (Found in src/Computer-Graphics/assignment)

abstractions.hpp: This contains all things I decided were annoying in OpenGL and abstracted away into a Object.
assignment.cpp: This contains the main method that actually runs the OpenGL program, it sets everything up and runs
FPSCamera.hpp: A Modified version of LearnOpenGL's flying camera.
assignment.hpp: Contains method definitions.

HOW TO COMPILE AND RUN

1) cd into Computer-Graphics
2) run build.sh

GAME WALKTHROUGH

To Lose:
1) Let antoni run into you or go hug him.

To Win:
1) Optional: Get Torch
2) Follow Red cube at feet and find papers
3) Enter Rocket
4) Win.